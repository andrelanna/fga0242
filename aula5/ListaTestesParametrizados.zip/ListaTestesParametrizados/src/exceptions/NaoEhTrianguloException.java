package exceptions;

public class NaoEhTrianguloException extends Exception {

}
