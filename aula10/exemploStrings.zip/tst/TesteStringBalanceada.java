package tst;

import static org.junit.Assert.*;

import org.junit.Test;

import app.Analisador;

public class TesteStringBalanceada {

	private Analisador a;

	/*
	 * "" -------> Ok
	 * " " ------> Ok
	 * "()" -----> Ok 
	 * "( )" ----> Ok
	 * "[]" -----> Ok
	 * "[ ]" ----> Ok
	 * "[()]" ---> Ok
	 * "[( )]" --> Ok 
	 * "[ () ]" -> Ok
	 * "[ ( )]" -> Ok
	 */
	
	@Test
	public void testSTringVazia() {
		a = new Analisador("");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void testStringEmBranco() {
		a = new Analisador(" ");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void testStringSimples() {
		a = new Analisador("()");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void testStringSimplesComEspaco() {
		a = new Analisador("( )");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void TestStringsSimplesAninhadas() {
		a = new Analisador("(())");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void TestStringsSimplesAninhadasComEspacos() {
		a = new Analisador("( ( ) )");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void TestStringSimplesColchetes() {
		a = new Analisador("[]");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void TestStringSimplesColchetesComEspacos() {
		a = new Analisador("[ ]");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void TestStringMistasAninhadasSimples() {
		a = new Analisador("[()]");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void TestStringMistasAninhadasComEspacos() {
		a = new Analisador("[( ) ]");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void TestStringSimplesChaves() {
		a = new Analisador("{}");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void testStringChavesComEspacos() {
		a = new Analisador("{ }"); 
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test
	public void testStringMistaAninhadasComEspacos() {
		a = new Analisador("{[() () ] [ ]()}{[][()][()]()}");
		assertEquals(true, a.ehBalanceada());
	}
	
	@Test 
	public void testStringCaracteres() {
		a = new Analisador("abcde");
		assertEquals(true, a.ehBalanceada());
	}
}
