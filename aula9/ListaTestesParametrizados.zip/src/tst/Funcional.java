package tst;

public interface Funcional {

}
