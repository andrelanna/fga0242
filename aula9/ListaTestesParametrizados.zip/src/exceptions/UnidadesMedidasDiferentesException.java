package exceptions;

public class UnidadesMedidasDiferentesException extends Exception {

}
