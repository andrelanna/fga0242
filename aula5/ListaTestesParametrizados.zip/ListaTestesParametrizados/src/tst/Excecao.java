package tst;

public interface Excecao {

}
