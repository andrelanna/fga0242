package app;

public class Analisador {

	private String string;
	private char[] pilha;
	private int ultimoElemento;

	public Analisador(String string) {
		this.string = string;
	}

	public boolean ehBalanceada() {
		if (string.length() == 0)
			return true;
		else if (string.length() > 0 && string.isBlank())
			return true;
		else {
			pilha = new char[string.length()];
			ultimoElemento = -1;
			return analisarString(0);
		}
	}

	private boolean analisarString(int i) {
		if (i >= string.length()) {
			return true;
		}
		if (string.charAt(i) == '(') {
			ultimoElemento++; 
			pilha[ultimoElemento] = '(';
			return true && analisarString(i+1); 
		} else if (string.charAt(i) == '[') {
			ultimoElemento++; 
			pilha[ultimoElemento] = '[';
			return true && analisarString(i+1);
		} else if (string.charAt(i) == '{') {
			ultimoElemento++; 
			pilha[ultimoElemento] = '{';
			return true && analisarString(i+1);
		} else if (string.charAt(i) == ')' && pilha[ultimoElemento] == '(') {
			ultimoElemento--;
			return true && analisarString(i+1);
		} else if(string.charAt(i) == ']' && pilha[ultimoElemento] == '[') {
			ultimoElemento--; 
			return true && analisarString(i+i);
		} else if(string.charAt(i) == '}' && pilha[ultimoElemento] == '{') {
			ultimoElemento--; 
			return true && analisarString(i+i);
		} else if (string.charAt(i) == ' ' || 
				   string.charAt(i) != '{' || 
				   string.charAt(i) != '[' || 
				   string.charAt(i) != '(' || 
				   string.charAt(i) != ')' || 
				   string.charAt(i) != ']' || 
				   string.charAt(i) != '{'  ) {
			return true && analisarString(i+1);
		}
			return false;
			
	}

}